//Numpy array shape [10]
//Min -0.114761903882
//Max 0.079103633761
//Number of zeros 0

#ifndef B23_H_
#define B23_H_

#ifndef __SYNTHESIS__
output_dense_bias_t b23[10];
#else
output_dense_bias_t b23[10] = {-0.0304106437, 0.0791036338, -0.1065143645, 0.0144797005, -0.0449558012, -0.0559802428, -0.0793009102, -0.1147619039, 0.0035849491, -0.0216946863};
#endif

#endif
